B05-EXTERIOR-SHAPE-04 外壳尺寸与外观试印包

单位：毫米。包含7件外罩/环台和1件灯窗。
8件均通过网格闭合、单连通体、正体积及220×220×250 mm打印床包络检查，XY余量5 mm。
STL已平移至正坐标，但摆放、支撑、切片参数与实物打印仍待验证。
建议PETG/ASA外壳、透光材料灯窗，仅供无动力外形与尺寸检查。
安装支座、定位舌、螺钉固定、灯板、接口板固定尚未完成；不可据此装配整机或承载机械臂。
当前J1环台中心(0,75) mm，内孔104 mm，外径144 mm；旧OD160法兰和旧承载板不适配，需下一模块重做。
许可：CC-BY-NC-4.0；商业使用需作者许可。
Required Notice: Odradek - Auromix contributors (https://github.com/Auromix/odradek)
